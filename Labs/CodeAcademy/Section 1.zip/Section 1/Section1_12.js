console.log(2*5)
console.log("Hello")