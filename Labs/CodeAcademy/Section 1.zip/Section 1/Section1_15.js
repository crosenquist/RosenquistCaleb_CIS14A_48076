if ("Caleb Patrick Rosenquist".length >= 7) {
    console.log("Let's take the high road.");
}
else {
    console.log("Let's take the low road.")
    
}