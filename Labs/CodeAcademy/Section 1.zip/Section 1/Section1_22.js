// Be careful with the substring's letter positions!
"wonderful day".substring(3,7);