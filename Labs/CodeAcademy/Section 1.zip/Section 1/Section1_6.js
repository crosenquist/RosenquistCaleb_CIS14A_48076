// This is a comment that the computer will ignore. 
// It is for your eyes only!
"cake".length