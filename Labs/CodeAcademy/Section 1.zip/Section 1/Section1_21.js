//An example of an if/else statement with modulo in the condition



if(200 % 2 == 0) {
    console.log("The first number is even");
} else {
    console.log("The first number is odd");
}