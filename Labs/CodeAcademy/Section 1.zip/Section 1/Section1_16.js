if("apple".length < "pear".length){
    console.log("The condition is true")
}else{
    console.log("The condition is false")
}