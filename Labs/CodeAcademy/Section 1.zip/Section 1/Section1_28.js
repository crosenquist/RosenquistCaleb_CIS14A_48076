// Not sure where to begin? Check the Hint!
var myFirstColor  = "Green";
var mySecondColor = "Blue";

if(myFirstColor.length > mySecondColor.length){
    console.log("I finished my first course!");
}else{
    console.log("Even though this is mathematically incorrect, I still finished my first course!");
}