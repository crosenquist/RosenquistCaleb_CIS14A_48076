var myColor = "Green";
console.log(myColor.length);