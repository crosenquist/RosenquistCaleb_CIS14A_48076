// Below is an example of printing the remainder of 18/4 using modulo:
// console.log(18 % 4); 

console.log(14%3);
console.log(99%8);
console.log(11%3);