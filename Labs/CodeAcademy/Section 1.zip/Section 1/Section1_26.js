// On line 2, declare a variable myName and give it your name.
var myName = "Caleb";
// On line 4, use console.log to print out the myName variable.
console.log(myName);
// On line 7, change the value of myName to be just the first 2 
// letters of your name.
myName=myName.substring(0,2);
// On line 9, use console.log to print out the myName variable.
console.log(myName);
