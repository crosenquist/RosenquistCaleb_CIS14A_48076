 if (("Jon".length * 2 / (2+1)) == 2)
{
    console.log("The answer makes sense!");
}else{
    console.log("Error! Error! Error!");
}
