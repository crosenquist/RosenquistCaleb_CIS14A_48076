// Declare a variable on line 3 called
// myCountry and give it a string value.
var myCountry = "tis of thee";

// Use console.log to print out the length of the variable myCountry.
console.log(myCountry.length);

// Use console.log to print out the first three letters of myCountry.
console.log(myCountry.substring(0,3));