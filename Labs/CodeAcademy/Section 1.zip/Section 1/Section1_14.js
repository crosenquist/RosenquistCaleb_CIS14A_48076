if ("dewdoal for gewgoal".length >= 7) {
    console.log("The lesson is making me print out a string, but I don't want to.");
}