// Also try the Q&A forum to get help
// The link is on the bottom left of the page!
confirm("Do you think you can handle taking on 13 credits, a job, and more schooling? You're going to need to get even more organized so hop to it and stop slacking. You'll have time to relax when you're done");
confirm("Good. Glad to hear it. Remember though, it will be hard and difficult, but you can make your journey much easier on yourself by pacing. Be diligent in your work. Study when you need to prepare. And be proactive in your duties.")